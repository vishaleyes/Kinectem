jush.tr.txt = { php: jush.php };
