<?php

/**
 * Logged In Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice alert alert-info info">
	<p><?php _e( 'You are already logged in.', 'firmasite' ); ?></p>
</div>
