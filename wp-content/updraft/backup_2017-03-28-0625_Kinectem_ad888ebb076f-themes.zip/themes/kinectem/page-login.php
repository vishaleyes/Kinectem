<?php 
*/
Template Name: Login Page
*/
get_header();?>
<div class="row body_bg" >
			<div class="container">
            	<div class="form_outr">
             <?php //wp_login_form(); ?>
              </div>
              <div class="signup_frm">Don't have an account? <a href="">Sign Up</a></div>
   		 </div> <!-- /container -->
		</div>
		<!-- End COntent div -->

<?php get_footer(); ?>