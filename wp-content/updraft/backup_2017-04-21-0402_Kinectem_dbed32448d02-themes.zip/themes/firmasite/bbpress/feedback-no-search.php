<?php

/**
 * No Search Results Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice alert alert-info">
	<p><?php _e( 'Oh bother! No search results were found here!', 'firmasite' ); ?></p>
</div>
